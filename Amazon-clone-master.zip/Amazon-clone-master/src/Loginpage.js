import React from 'react'
import './Loginpage.css';

function Loginpage() {
    return (
        <div>
            <h1>login page</h1>
        </div>
    )
}

export default Loginpage
