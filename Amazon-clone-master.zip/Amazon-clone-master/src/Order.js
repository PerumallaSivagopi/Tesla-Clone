import React from 'react'
import Header from './Header'


function Order() {
    return (
        <div>
            <Header/>
            <h1>order</h1>
        </div>
    )
}

export default Order
