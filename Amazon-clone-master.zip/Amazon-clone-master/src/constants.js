export const HEADER_ELEMENTS = {
    HELLO: "Hello Ananya",
    SIGNIN: "Sign In",
    RETURN: "Returns"

}