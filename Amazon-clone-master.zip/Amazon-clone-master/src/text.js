import React from "react";

function Text({name ,age}) {
    return (
        <div>
            <h1>HOME PAGE!</h1>
            <h1>hellooo, annaya</h1>
            <h1>helloo, {name} {age}</h1>
        </div>


    )
}

export default Text;